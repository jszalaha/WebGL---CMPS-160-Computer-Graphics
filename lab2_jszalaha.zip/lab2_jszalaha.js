// Jordan Zalaha, 1438462
// jszalaha@ucsc.edu

var gl;
var index = 0;
var count = 0;
var state = "start";
var Pos;

function setupWebGL(){

	var canvas = document.getElementById("gl-canvas");
	
	// initializes the global var gl with the webgl
	// context of the canvas element created in the
	// html file which we will use for rendering
	gl = canvas.getContext("experimental-webgl");
}

function setupShaders() {
	var vsSource = "\
		attribute vec2 aPosition;\n\
		void main(){\n\
		gl_Position = vec4(aPosition, 0.0, 1.0);}\n\
		";
	
	// creates a WebGLShader object of type 
	// VERTEX_SHADER
	var vShader = gl.createShader(gl.VERTEX_SHADER);
	
	// sets vShaders source code as the above
	// vsSource
	gl.shaderSource(vShader, vsSource);
	
	// compiles the shader
	gl.compileShader(vShader);
	
	var fsSource = "\
		void main()\n\
		{gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);}\n\
		";
	
	// the following three lines perform the same
	// task as above but in this case for a FRAGMENT_
	// SHADER type
	var fShader = gl.createShader(gl.FRAGMENT_SHADER);
	gl.shaderSource(fShader, fsSource);
	gl.compileShader(fShader);
	
	// creates a new WebGLProgram object with
	// program as a reference
	var program = gl.createProgram();
	
	// the following two lines attach the vertex shader
	// and fragment shader to the program
	gl.attachShader(program, vShader);
	gl.attachShader(program, fShader);
	
	// configures the program such that the value of
	// aPosition in the vShader is fetched from the 
	// attribute slot designated by index
	gl.bindAttribLocation(program, index, "aPosition");
	
	// establishes a link between the two shaders in
	// the program
	gl.linkProgram(program);
	
	// makes program the current program
	gl.useProgram(program);
}

function drawBackground() {
	// defines the color used when clearing the 
	// color buffer
	gl.clearColor(0.0, 0.4, 0.8, 1.0);
	
	// clears the color buffer using the color
	// specified above
	gl.clear(gl.COLOR_BUFFER_BIT);
}

// returns a random number between -1 and 1
function rand() {
	return Math.random()*2 - 1; 
}

// generates 3 random coords. and calls triangle()
// on them
function randomTriangle() {
	var positions = [
		rand(), rand(),	// vertex 1
		rand(), rand(),	// vertex 2
		rand(), rand()	// vertex 3
	];
	
	triangle(positions);
}

// clears the scene then draws 10 randomly placed
// trangles, then sets the state to random
function drawRandomTriangles() {
	drawBackground();
	for(var ind = 1; ind <= 10; ++ind){
		randomTriangle();
	}
	state = "random";
}

function subdivideTriangle() {
	// clears the scene
	drawBackground();
	// if the program just started, or the 
	// random button was pushed last
	if (state == "random" || state == "start") {
		// clear the global Pos variable
		Pos = new Array();
		// set the vertices for the starting triangle
		var position = [
			-0.8, -0.8,
			0.8, -0.8,
			0.0, 0.8
		];
		// push it onto the array of triangles Pos
		Pos.push(position);
		// print it out
		triangle(Pos[0]);
	}
	// otherwise
	else {
		// subdivide it
		subdivide();
	}
	// set state to "subdivide"
	state = "subdivide";
}

// draws a triangle given an array of vertices
function triangle(positions) {
	// converts to float32array
	var vPositions = new Float32Array(positions);
	// creates a buffer for the verts
	var vBuffer = gl.createBuffer();
	// bind it to ARRAY_BUFFER
	gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
	// set the vert positions as the buffer's data
	gl.bufferData(gl.ARRAY_BUFFER, vPositions, gl.STATIC_DRAW);
	// use atrribarray 0
	gl.enableVertexAttribArray(index);
	// set data type for attribute (float) and set fetch 
	// instructions
	gl.vertexAttribPointer(index, 2, gl.FLOAT, false, 0, 0);
	// draw the triangle as a wireframe
	gl.drawArrays(gl.LINE_LOOP, 0, 3);
}

// Subdivides each triangle in the global array Pos
// into 4 sub-triangles. Each sub array in Pos is replaced
// by 4 new ones each call.
function subdivide() {
	var k = Pos.length;
	var subPos1;
	var subPos2;
	var subPos3;
	var subPos4;
	// for every triangle to be subdivided
	for(var i = 0; i < k; ++i){
	// shift off the first triangle
	var arr = Pos.shift();
	
	// get the midpoints of each line and form 4 new
	// triangles using them and the original vertices
	// pushing each newly formed triangle onto the 
	// main array Pos as it goes.
	subPos1 = [			
		arr[0], arr[1],							// triangle 1
		(arr[0]+arr[2])/2, (arr[1]+arr[3])/2,
		(arr[0]+arr[4])/2, (arr[1]+arr[5])/2
	];
	Pos.push(subPos1);
	
	subPos2 = [
		arr[2], arr[3],							// triangle 2
		(arr[2]+arr[4])/2, (arr[3]+arr[5])/2,		
		(arr[2]+arr[0])/2, (arr[3]+arr[1])/2
	];
	Pos.push(subPos2);
	
	subPos3 = [
		arr[4], arr[5],							// triangle 3
		(arr[0]+arr[4])/2, (arr[1]+arr[5])/2,
		(arr[2]+arr[4])/2, (arr[3]+arr[5])/2
	];
	Pos.push(subPos3);
	
	subPos4 = [									// triangle 4
		(arr[0]+arr[2])/2, (arr[1]+arr[3])/2,
		(arr[2]+arr[4])/2, (arr[3]+arr[5])/2,
		(arr[0]+arr[4])/2, (arr[1]+arr[5])/2
	];
	Pos.push(subPos4);
	}
	// then go through the newly modified array Pos 
	// and call triangle() on each element
	for(var i = 0; i < Pos.length; ++i){
		triangle(Pos[i]);
	}
}
// initializes the program
function initialize() {
	setupWebGL();
	setupShaders();
	drawBackground();
}

window.onload = initialize;