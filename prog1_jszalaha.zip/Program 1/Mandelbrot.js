// Program 1
// Jordan Zalaha, 1438462
// jszalaha@ucsc.edu
//////////////////////////
var gl;
var index = 0;
var program;
var projectionMatrix1;
var projectionMatrix2;
var projectionMatrix3;
var projectionMatrix4;
var projectionMatrix5;

function setupWebGL(){

	var canvas = document.getElementById("gl-canvas");
	
	// initializes the global var gl with the webgl
	// context of the canvas element created in the
	// html file which we will use for rendering
	gl = canvas.getContext("experimental-webgl");
}

function setupShaders(X,Y) {
	// vsSource has been modified to include uniform
	// mat4 variables which serve as the transformations
	// from object coordinates, to world coordinates
	// (-255,255), rotating the object to isometric view,
	// and then to viewport scale (-1,1)
	var vsSource = "\
		attribute vec3 aPosition;\n\
		uniform mat4 wScale;\n\
		uniform mat4 wTrans;\n\
		uniform mat4 wRotate1;\n\
		uniform mat4 wRotate2;\n\
		uniform mat4 vpScale;\n\
		void main(){\n\
		gl_Position = vec4(aPosition, 1.0)*wScale*wTrans*wRotate2*wRotate1*vpScale;}\n\
		";
	
	// creates a WebGLShader object of type 
	// VERTEX_SHADER
	var vShader = gl.createShader(gl.VERTEX_SHADER);
	
	// sets vShaders source code as the above
	// vsSource
	gl.shaderSource(vShader, vsSource);
	
	// compiles the shader
	gl.compileShader(vShader);
	
	var fsSource = "\
		void main()\n\
		{gl_FragColor = vec4(0.0, 1.0, 0.0, 1.0);}\n\
		";
	
	// the following three lines perform the same
	// task as above but in this case for a FRAGMENT_
	// SHADER type
	var fShader = gl.createShader(gl.FRAGMENT_SHADER);
	gl.shaderSource(fShader, fsSource);
	gl.compileShader(fShader);
	
	// creates a new WebGLProgram object with
	// program as a reference
	program = gl.createProgram();
	
	// the following two lines attach the vertex shader
	// and fragment shader to the program
	gl.attachShader(program, vShader);
	gl.attachShader(program, fShader);
	
	// configures the program such that the value of
	// aPosition in the vShader is fetched from the 
	// attribute slot designated by index
	gl.bindAttribLocation(program, index, "aPosition");
	
	// establishes a link between the two shaders in
	// the program
	gl.linkProgram(program);
	
	// makes program the current program
	gl.useProgram(program);
	
	// defines each of the transformation matrices used
	// in the vertex shader source code
	projectionMatrix1 = gl.getUniformLocation(program, "wScale");	
	projectionMatrix2 = gl.getUniformLocation(program, "wTrans");	
	projectionMatrix3 = gl.getUniformLocation(program, "wRotate1");	
	projectionMatrix4 = gl.getUniformLocation(program, "wRotate2");	
	projectionMatrix5 = gl.getUniformLocation(program, "vpScale");
}

// this function calculates a Mandelbrot height value 
// 0-255 based on the complex number a+bi given a and b
function calcHeight(a,b) {
	var znR = a;
	var znI = b;
	var z1R = a;
	var z1I = b;
	var znR2;
	var znModulusSquare;
	
	// ensures a maximum iteration(height) of 255
	for(var i = 0; i < 255; i++) {
		znR2 = znR;
		// calculate the square of the modulus
		znModulusSquare = znR*znR + znI*znI;
		// if it exceeds our max distance
		// then return the number of iterations
		// it took to do so
		if(znModulusSquare >= 4){
			return i;
		}
		// apply formula zn+1=zn^2+c component-wise
		znR = znR*znR - znI*znI + z1R;
		znI = 2*znR2*znI + z1I;		
	}
	return 0;
}

// main function
// creates two 2D arrays, the columns and the rows
// of the matrix. Each element is an array of values
// representing the vertices in the row/col in groups
// of three values: x,y,height. These row and column 
// arrays are then passed in element by element 
// (row/col by row/col) into drawHeights().
// also initializes the transformation matrices used
// by the vertex shader
function Mandelbrot(x,y,left,right,bottom,top) {
	// ensure incoming values are correct types
	var X = parseInt(x);
	var Y = parseInt(y);
	var Left = parseFloat(left);
	var Right = parseFloat(right);
	var Bottom = parseFloat(bottom);
	var Top = parseFloat(top);
	// create two arrays: the list of rows
	// and the list of columns
	var heightsRows = new Array();
	var heightsCols = new Array();
	// calculate dx and dy
	var dx = ( Right - Left ) / (X - 1);
	var dy = ( Top - Bottom ) / (Y - 1);
	// helper arrays
	var row;
	var col;
	// for each column(x-value) from 0 to x-1
	for(var i = 0; i < X; i++) {
		// create new vertex array
		col = new Array();
		// for each vertex in that column
		for(var j = 0; j < Y; j++){
			// push the x and y indices followed
			// by the Mandelbrot height
			col.push(i);
			col.push(j);
			col.push(calcHeight(Left + dx*i, Top + dy*j));
		}
		// push the column
		heightsCols.push(col);		
	}
	// same method as before but for the rows
	for(var i = 0; i < Y; i++) {
		row = new Array();
		for(var j = 0; j < X; j++){
			row.push(j);
			row.push(i);
			row.push(calcHeight(Left + dx*j, Top + dy*i));
		}
		heightsRows.push(row);		
	}
	// calculate the world scaling factors
	var Sx = 510/(X-1);
	var Sy = 510/(Y-1);
	// calc the world translation values
	var Tx = -255;
	var Ty = -255;
	// calc the veiwport scaling factor
	var vpS = 2/765;
	// initialize the transformation arrays
	// as 1D arrays
	var worldScaleM = [
		Sx, 0, 0, 0,
		0, Sy, 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	];
	var worldTransM = [
		1, 0, 0, Tx,
		0, 1, 0, Ty,
		0, 0, 1, 0,
		0, 0, 0, 1
	];
	var worldRotate1M = [
		 1, 0, 0, 0,
		 0, Math.cos(35.26), -Math.sin(35.26), 0,
		 0, Math.sin(35.26), Math.cos(35.26), 0,
		 0, 0, 0, 1
	];
	var worldRotate2M = [
		Math.cos(45), -Math.sin(45), 0, 0,
		Math.sin(45), Math.cos(45), 0, 0,
		0, 0, 1, 0,
		0, 0, 0, 1
	];
	var vpScaleM = [
		vpS, 0, 0, 0,
		0, vpS, 0, 0,
		0, 0, vpS, 0,
		0, 0, 0, 1
	];	
	
	// convert them to Float32Array type and pass
	// them into the vertex shader
	gl.uniformMatrix4fv(projectionMatrix1, false, new Float32Array(worldScaleM));	
	gl.uniformMatrix4fv(projectionMatrix2, false, new Float32Array(worldTransM));	
	gl.uniformMatrix4fv(projectionMatrix3, false, new Float32Array(worldRotate1M));	
	gl.uniformMatrix4fv(projectionMatrix4, false, new Float32Array(worldRotate2M));	
	gl.uniformMatrix4fv(projectionMatrix5, false, new Float32Array(vpScaleM));	
	
	// clear and draw background color
	gl.clear(gl.COLOR_BUFFER_BIT);
	
	// draw the rows
	while(heightsRows.length > 0) {
		drawHeights(heightsRows.shift());
	}
	// draw the columns
	while(heightsCols.length > 0) {
		drawHeights(heightsCols.shift());
	}
}

function drawHeights(arry) {	
	// converts to float32array
	var vPositions = new Float32Array(arry);
	// creates a buffer for the verts
	var vBuffer = gl.createBuffer();
	// bind it to ARRAY_BUFFER
	gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
	// set the vert positions as the buffer's data
	gl.bufferData(gl.ARRAY_BUFFER, vPositions, gl.STATIC_DRAW);
	// use atrribarray 0
	gl.enableVertexAttribArray(index);
	// set data type for attribute (float) and set fetch 
	// instructions
	gl.vertexAttribPointer(index, 3, gl.FLOAT, false, 0, 0);
	// connect verts by line strip
	gl.drawArrays(gl.LINE_STRIP, 0, arry.length/3);
}

function initialize() {
	setupWebGL();
	setupShaders();
	gl.clearColor(0.0, 0.0, 0.0, 1.0);
	gl.clear(gl.COLOR_BUFFER_BIT);
}

window.onload = initialize;