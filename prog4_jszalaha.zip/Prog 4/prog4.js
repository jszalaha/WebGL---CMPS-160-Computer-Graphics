// Program 4
// Jordan Zalaha - 1438462
// jszalaha@ucsc.edu
/////////////////////////////////////////////

window.onload = initialize;

// GLOBAL DECLARATIONS //////////////////////
var renderer, 
	canvas,
	scene,
	objects,
	camera,		
	raycaster,
	intersects,
	selection,
	selected,
	mouse,
	mouse_x_prev,
	mouse_y_prev,
	mouse_state,
	select_state,
	examine_state,
	lookingAround,
	theta,
	r,
	origin,
	camera_pos,
	WINDOW_WIDTH = 720,
	WINDOW_HEIGHT = 480;
/////////////////////////////////////////////

// CORE FUNCTIONS ///////////////////////////
function initialize() {
	// creates the canvas element and 
	// appends it onto the html page
	renderer = new THREE.WebGLRenderer();
	renderer.setSize( WINDOW_WIDTH, WINDOW_HEIGHT );
	canvas = renderer.domElement;
	document.body.appendChild( canvas );	
	
	// creates a new scene and sets its position
	// to the origin
	scene = new THREE.Scene();
	scene.position.set( 0, 0, 0 );
	
	// creates a perspective projection camera
	// positioned 100 units along the z axis
	// and points it at the origin
	camera = new THREE.PerspectiveCamera( 75,WINDOW_WIDTH/WINDOW_HEIGHT, 0.1, 1000 );
	camera.position.z = 100;
	scene.add( camera );
	
	// eventListeners
	canvas.addEventListener( "mousedown", onMouseDown, false );
	document.addEventListener( "mouseup", onMouseUp, false );
	document.addEventListener( "mousemove", onMouseMove, false );
	
	// initialize the scene
	initScene();
	
	// initialize raycasting element
	raycaster = new THREE.Raycaster();
	
	// initialize mouse position vector
	mouse = new THREE.Vector2();
	
	// initialize state of the controls
	mouse_state = "not-clicked";
	select_state = "not-selected";
	examine_state = "not-examining";
	
	theta = 0;
	lookingAround = false;
	camera_pos = new THREE.Vector3();
	origin = new THREE.Vector3(0,0,0);
	
	// draw the scene
	draw();
}

function update() {
	if( examine_state == "examining" ) {
		if( selected ){
			theta += Math.PI/64;
			camera.lookAt( selected.object.position );
			camera.position.y = selected.object.position.y;
			camera.position.z = r * Math.sin(theta);
			camera.position.x = r * Math.cos(theta);
		}
	}
	else if( lookingAround == true ) {
		theta += Math.PI/64;
		camera.lookAt( origin );
		camera.position.y = 0;
		camera.position.z = r * Math.sin(theta);
		camera.position.x = r * Math.cos(theta);
	}
	else {
		theta = 0;
	}
}

function draw() {
	update();
	requestAnimationFrame( draw );
	renderer.render( scene, camera );
}
/////////////////////////////////////////////

// EVENT HANDLERS ///////////////////////////
function onMouseDown( event ) {
	// set the state of mouse control
	if( event.button == 0 ){ mouse_state = "left-clicked"; }
	else if( event.button == 1 ) { mouse_state = "wheel-clicked"; }
	else if( event.button == 2 ) { mouse_state = "right-clicked"; }
	
	calcMousePosition( event );
	mouse_x_prev = mouse.x;
	mouse_y_prev = mouse.y;
	
	// cast a ray from the camera, through the
	// mouse coordinates and into the scene
	raycaster.setFromCamera( mouse.clone(), camera );
	
	// get all intersections with shark objects
	intersects = raycaster.intersectObjects( objects.children );
	
	// set color of any shark objects intersected
	// to red and set selection status to true if
	// any sharks are selected
	if( intersects.length > 0 ) { 
		selection = intersects[0]; 
		selection.object.material.color.set( 0xff0000 );
	}
	else {
		selection = null;
	}
	
	if( event.detail == 2 && selection ) {
		select_state = "selected";
		selected = selection;
		selected.object.material.color.set( 0x00ff00 );		
	}else {
		select_state = "not-selected";
		selected = null;
	}
}

function onMouseUp( event ) {
	// set state of mouse controls
	mouse_state = "not-clicked";
	
	// return any selected shark's color
	// back to gray
	if( intersects.length > 0 && !selected ) {
		for( var i = 0; i < objects.children.length; ++i ) {
			intersects[i].object.material.color.set( 0x777777 );
		}
	}
	if( select_state == "selected" ) {
		selected.object.material.color.set( 0x00ff00 );
	}
}

function onMouseMove( event ) {
	calcMousePosition( event );
	// get the change in mouse position
	var x_diff = (mouse.x - mouse_x_prev) * 100;
	var y_diff = (mouse.y - mouse_y_prev) * 67;
	if( mouse_state != "not-clicked") {
		mouse_x_prev = mouse.x;
		mouse_y_prev = mouse.y;
	}
	
	if( mouse_state == "left-clicked" ) {
		if( selection != null ) {
			selection.object.position.x = selection.object.position.x + x_diff;
			selection.object.position.y = selection.object.position.y + y_diff;
		}else {
			camera.position.x = camera.position.x + x_diff;
			camera.position.y = camera.position.y + y_diff;
		}
	}else if( mouse_state == "wheel-clicked" ) {
		if( selection != null ) {
			var	scale = (Math.abs(y_diff) / 67);
			
			if( y_diff >= 0) {
				selection.object.scale.x += scale;
				selection.object.scale.y += scale;
				selection.object.scale.z += scale;
			}else {
				selection.object.scale.x -= scale;
				selection.object.scale.y -= scale;
				selection.object.scale.z -= scale;
			}
		}else {
			camera.position.z = camera.position.z + y_diff;
		}
	}else if( mouse_state == "right-clicked" ) {
		var	axis = new THREE.Vector3(y_diff, -x_diff, 0);
		axis.normalize();
		
		if( selection != null ) {			
			var rotation = ( Math.abs(x_diff/100) + Math.abs(y_diff/67) ) / 2;
			selection.object.rotateOnAxis(
				axis, rotation * Math.PI
			);
		}else {
			
		}
	}
}
////////////////////////////////////////////

// SUB-ROUTINES ////////////////////////////
function initScene() {
	initLights();
	fillScene();
	initSceneObjects();
}

// creates and adds lights to the scene
function initLights() {
	// create a light to serve as the global lighting
	var sun = new THREE.DirectionalLight( 0xffffff, 1 );
	sun.position.set( 1, 1, 1 );
	scene.add( sun );
}

// add scene objects HERE
function fillScene() {
	objects = new THREE.Object3D();
	objects.add( createShark() );
	objects.add( createShark().translateZ(-25) );
	scene.add( objects );
}

// set transform initialization for scene objects HERE
function initSceneObjects() {
	
}

function examineObject() {
	if( selected ){
		if(examine_state != "examining"){
			examine_state = "examining";
			r = selected.object.position.distanceTo( camera.position );
			camera_pos = camera.position;
		}else {
			examine_state = "not-examining";
			camera.position.set(0, 0, 100);
			camera.lookAt(new THREE.Vector3(0,0,0));
		}
	}else {
			examine_state = "not-examining";
	}
}

function lookAround() {
	if(lookingAround == false && examine_state != "examining") {
		lookingAround = true;
		r = origin.distanceTo( camera.position );
		camera_pos = camera.position;
	}else {
		camera.position.set(0, 0, 100);
		camera.lookAt(new THREE.Vector3(0,0,0));
		lookingAround = false;
	}		
}

// creates a returns a shark mesh
function createShark() {
	// create a new geometry object
	var sharkGeo = new THREE.Geometry();
	
	// push all vertices onto the geometry
	// object
	for(var i = 0; i < SHARK_COORD.length; ++i){
		sharkGeo.vertices.push( new THREE.Vector3(
								SHARK_COORD[i][0],
								SHARK_COORD[i][1],
								SHARK_COORD[i][2]
								)
							);
	}
	
	// push all faces (tessellated) onto
	// the geometry object
	for( var i = 0; i < SHARK_POLY.length; ++i ){
		for( var j = 3; j < SHARK_POLY[i].length; ++j ){
			sharkGeo.faces.push( new THREE.Face3(
								SHARK_POLY[i][1]-1,
								SHARK_POLY[i][j-1]-1,
								SHARK_POLY[i][j]-1
								)
							);
		}
	}
	
	// compute all face normals
	sharkGeo.computeFaceNormals();
	// compute all vertex normals based
	// off of those face normals
	// (for smooth shading)
	sharkGeo.computeVertexNormals();
	// create a new gray lambert material
	// for the shark
	var sharkMat = new THREE.MeshPhongMaterial( {color: 0x777777} );
	// create a new mesh object with the
	// shark geometry and the lambert material
	var shark = new THREE.Mesh( sharkGeo, sharkMat );
	
	return shark;
}

function calcMousePosition( event ) {
	// get mouse coordinates in terms 
	// of viewport coordinates (projection plane)
	mouse.x = 2 * ( (event.clientX - canvas.offsetLeft) / WINDOW_WIDTH ) - 1;
	mouse.y = 1 - 2 * ( (event.clientY - canvas.offsetTop) / WINDOW_HEIGHT);
}
///////////////////////////////////////////