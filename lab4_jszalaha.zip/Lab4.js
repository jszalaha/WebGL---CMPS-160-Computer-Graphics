//////////////////////////////////
// Lab 4						//
// Jordan Zalaha - 1438462		//
// jszalaha@ucsc.edu			//
//////////////////////////////////

var gl;
var canvas;
var program;
var WORLD_MAX_X = 100;
var WORLD_MAX_Y = 100;
var WORLD_MAX_Z = 100;
var WORLD_MIN_X = -100;
var WORLD_MIN_Y = -100;
var WORLD_MIN_Z = -100;
var projectionMatrix;
var normalMatrix;
var projection;
var invProjection;
var mouse;

// setupWebGL() //////////////////////////////////////////////////////////////////////////
function setupWebGL(){
	var canvas = document.getElementById("gl-canvas");
	gl = canvas.getContext("experimental-webgl");
	canvas.addEventListener("mousedown", getPosition, false);
}

// setupShaders() ////////////////////////////////////////////////////////////////////////
function setupShaders() {
	var vsSource = "\
		attribute vec3 vPosition;\n\
		attribute vec3 vsNormal;\n\
		attribute vec3 vfNormal;\n\
		uniform mat4 ProjM;\n\
		uniform mat3 NormM;\n\
		uniform mat4 projection;\n\
		uniform mat4 invProjection;\n\
		uniform vec2 mouse;\n\
		varying highp vec4 vColor;\n\
		void main()\n\
		{\n\
		highp vec3 dLightDir = vec3(1.0/sqrt(3.0),-1.0/sqrt(3.0),1.0/sqrt(3.0));\n\
		highp vec4 dLightColor = vec4(1.0,1.0,1.0,1.0);\n\
		highp vec4 baseColor = vec4(0.1,0.1,0.1,1.0);\n\
		highp vec4 ambientColor = vec4(0.0,0.0,0.0,0.1);\n\
		highp vec3 tranNormal_s = NormM * vsNormal;\n\
		highp vec3 tranNormal_f = NormM * vfNormal;\n\
		highp float sN = sqrt(dot(tranNormal_s,tranNormal_s));\n\
		highp float fN = sqrt(dot(tranNormal_f,tranNormal_f));\n\
		tranNormal_s = tranNormal_s / sN;\n\
		tranNormal_f = tranNormal_f / fN;\n\
		highp float vsX = max(dot(tranNormal_s, dLightDir),0.0);\n\
		highp float vfX = max(dot(tranNormal_f, dLightDir),0.0);\n\
		gl_Position = ProjM * vec4(vPosition, 1.0);\n\
		//vColor = baseColor * dLightColor * vsX + ambientColor;\n\
		highp float x = (2.0 * mouse[0]) / 720.0 - 1.0;\n\
		highp float y = 1.0 - (2.0 * mouse[1]) / 720.0;\n\
		highp vec4 ray_eye = invProjection * vec4(x,y,-1.0,1.0);\n\
		ray_eye /= sqrt(dot(ray_eye,ray_eye));\n\
		if(ray_eye[0] == gl_Position[0] || ray_eye[1] == gl_Position[1]){\n\
			vColor = baseColor * dLightColor * vfX + ambientColor;\n\
		}\n\
		else {\n\
			vColor = baseColor * dLightColor * vsX + ambientColor;\n\
		}\n\
		}";

	var vShader = gl.createShader(gl.VERTEX_SHADER);
	gl.shaderSource(vShader, vsSource);
	gl.compileShader(vShader);
	
	var fsSource = "\
		varying lowp vec4 vColor;\n\
		void main()\n\
		{gl_FragColor = vColor;}";

	var fShader = gl.createShader(gl.FRAGMENT_SHADER);
	gl.shaderSource(fShader, fsSource);
	gl.compileShader(fShader);
	
	program = gl.createProgram();
	gl.attachShader(program, vShader);
	gl.attachShader(program, fShader);
	gl.bindAttribLocation(program, 0, "vPosition");
	gl.bindAttribLocation(program, 1, "vsNormal");
	gl.bindAttribLocation(program, 2, "vfNormal");
	gl.linkProgram(program);
	
	console.log(gl.getShaderInfoLog(vShader));
	
	gl.useProgram(program);
	
	projectionMatrix = gl.getUniformLocation(program, "ProjM");
	normalMatrix = gl.getUniformLocation(program, "NormM");
	projection = gl.getUniformLocation(program, "projection");
	invProjection = gl.getUniformLocation(program, "invProjection");
	mouse = gl.getUniformLocation(program, "mouse");
}

// getPosition(event) ////////////////////////////////////////////////////////////////////
// Retrieves and returns the position of the click event
function getPosition(event) {
	var x = new Number();
	var y = new Number();
	var canvas = document.getElementById("gl-canvas");
	if(event.x != null && event.y != null){
		x = event.x;
		y = event.y;
		x -= canvas.offsetLeft;
		y -= canvas.offsetTop;
	}	
	gl.uniform1f(mouse, new Float32Array([x,y]));
}

function switchStyle(event) {
	var position = getPosition(event);
	
	
	
}

// initialize() //////////////////////////////////////////////////////////////////////////
// Runs on load 																		
// Initializes webGl and shaders, sets clear color and clear depth						
function initialize() {
	setupWebGL();
	setupShaders();
	gl.clearColor(0.0, 0.0, 0.2, 1.0);
	gl.clearDepth(0.0);
	gl.depthFunc(gl.GREATER);
	gl.enable(gl.DEPTH_TEST);
	gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
	
	drawShark();
}

// drawTriangles(pos,norm) ///////////////////////////////////////////////////////////////
// This function draws an array (pos) of vertices as triangles							
// using an array (norm) of normals as the normal values of 							
// each vertex																			
// Both arrays are should be arranged as a continuous string 							
// of x, y, and z elements																
function drawTriangles(pos, normS, normF) {
	var vPositions = new Float32Array(pos);
	var vsNorms = new Float32Array(normS);
	var vfNorms = new Float32Array(normF)
	
	// creates a buffer for the verts
	var vpBuffer = gl.createBuffer();
	// bind it to ARRAY_BUFFER
	gl.bindBuffer(gl.ARRAY_BUFFER, vpBuffer);
	// set the vert positions as the buffer's data
	gl.bufferData(gl.ARRAY_BUFFER, vPositions, gl.STATIC_DRAW);
	var pLoc = gl.getAttribLocation(program, "vPosition");
	// set data type for attribute (float) and set fetch 
	// instructions
	gl.vertexAttribPointer(pLoc, 3, gl.FLOAT, false, 0, 0);
	
	// handle the smooth vertex normals in a separate buffer
	// to be passed into the vShader with attrib location 1
	var svnBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, svnBuffer);
	gl.bufferData(gl.ARRAY_BUFFER, vsNorms, gl.STATIC_DRAW);
	var snLoc = gl.getAttribLocation(program, "vsNormal");
	gl.vertexAttribPointer(snLoc, 3, gl.FLOAT, false, 0, 0);
	
	// handle the flat vertex normals in a separate buffer
	// to be passed into the vShader with attrib location 2
	var fvnBuffer = gl.createBuffer();
	gl.bindBuffer(gl.ARRAY_BUFFER, fvnBuffer);
	gl.bufferData(gl.ARRAY_BUFFER,vfNorms, gl.STATIC_DRAW);
	var fnLoc = gl.getAttribLocation(program, "vfNormal");
	gl.vertexAttribPointer(fnLoc, 3, gl.FLOAT, false, 0, 0);
	
	// enable the position and normal attributes in
	// the vertex shader
	gl.enableVertexAttribArray(pLoc);
	gl.enableVertexAttribArray(snLoc);
	gl.enableVertexAttribArray(fnLoc);
	
	gl.drawArrays(gl.TRIANGLES, 0, pos.length/3);
}

// vpTransform() /////////////////////////////////////////////////////////////////////////
// Creates and returns a matrix for transforming the world coord
// system to a viewport coord system of (-1/1,-1/1,-1/1)
function vpTransform() {
	/*
	var vpTrans = [
		2/(WORLD_MAX_X - WORLD_MIN_X), 0, 0, 0,
		0, 2/(WORLD_MAX_Y - WORLD_MIN_Y), 0, 0,
		0, 0, 2/(WORLD_MAX_Z - WORLD_MIN_Z), 0,
		0, 0, 0, 1
	];
	
	return vpTrans;
	*/
	
	var vpScaleM4 = scaleM(	2/(WORLD_MAX_X - WORLD_MIN_X),
							2/(WORLD_MAX_Y - WORLD_MIN_Y),
							2/(WORLD_MAX_Z - WORLD_MIN_Z)
							);
	
	return vpScaleM4;
}

// worldTransform() //////////////////////////////////////////////////////////////////////
// Creates a transformation matrix from object space into world space
function worldTransform() {
	var result = translate(25,0,0);
	//result = mult(result, scaleM(1.5,1.5,1.5))
	result = mult(result, rotate(45,[0,1,0]));
	
	
	return result;
}

// viewTransform() ///////////////////////////////////////////////////////////////////////
function viewTransform() {
	var result = translate(0,0,-125);
	
	return result;	
}

// perspectiveTransform() ////////////////////////////////////////////////////////////////
// Creates and returns a composite matrix for transforming the
// coordinate system (prior to applying projection) to a 
// perspective view, maintains z value
function perspectiveProj() {
	
	var result = perspective(50,512/512,25,250);
	
	return result;	
}

// projMatrix(M1, M2, M3) ////////////////////////////////////////////////////////////////
// Builds and returns a projection matrix by multiplying 
// M1, M2 and M3 left to right
function compMatrix(M1, M2, M3) {
	var result = M1;
	
	if(M2){ result = mult(result, M2); }
	if(M3){	result = mult(result, M3); }
	
	return result;
}

function calcRay(event) {
	var mouse = getPosition(event);
	
	var x = (2.0 * mouse[0]) / 720 - 1.0;
	var y = 1.0 - (2.0 * mouse[1]) / 720;
	var z = 1.0;
	var invP = inverse(perspectiveProj());
	var ray_eye = new Array();
	ray_eye.push(invP[0][0] * x + invP[0][1] * y - invP[0][2] + invP[0][3]);
	ray_eye.push(invP[1][0] * x + invP[1][1] * y - invP[1][2] + invP[1][3]);
	ray_eye.push(-1.0);
	ray_eye.push(1.0);
	ray_eye = normalize(ray_eye);
	return ray_eye;
}

function intersects(event,object) {
	ray = calcRay(event);
	
	
}

// drawShark() ///////////////////////////////////////////////////////////////////////////
// Pulls coord and polygon data from shark.js and populates
// two arrays: 
// one (coordArray) contains the vertex data as a continuous 
// string of x, y, and z values
// the other (normArray) contains the corresponding smooth 
// normals for each vertex in coordArray
function drawShark() {
	
	var polyArray = new Array();
	var coordArray = new Array();
	var smoothNormArray = new Array();
	var flatNormArray = new Array();
	var vertNorm = new Array(SHARK_COORD.length);
	var polyNorm = new Array(SHARK_POLY.length);
	var a, b, c;
	
	// create triangulated polygon array
	for(var i = 0; i < SHARK_POLY.length; ++i){
		polyArray.push(new Array());
		for(var j = 3; j < SHARK_POLY[i].length; ++j){
			polyArray[i].push(SHARK_POLY[i][1]-1);
			polyArray[i].push(SHARK_POLY[i][j-1]-1);
			polyArray[i].push(SHARK_POLY[i][j]-1);
		}
	}
	
	// calculate normal per triangle and assign to
	// each vertex in that triangle
	for(var i = 0; i < polyArray.length; ++i){
		for(var k = 0; k < polyArray[i].length; k+=3){
			a = subtract(SHARK_COORD[polyArray[i][k+1]], SHARK_COORD[polyArray[i][k]]);
			b = subtract(SHARK_COORD[polyArray[i][k+2]], SHARK_COORD[polyArray[i][k]])
			c = cross(a, b);
			if(vertNorm[polyArray[i][k]] == null){
				vertNorm[polyArray[i][k]]= new Array();
			}
			vertNorm[polyArray[i][k]].push(c);
			if(vertNorm[polyArray[i][k+1]] == null){
				vertNorm[polyArray[i][k+1]]= new Array();
			}
			vertNorm[polyArray[i][k+1]].push(c);
			if(vertNorm[polyArray[i][k+2]] == null){
				vertNorm[polyArray[i][k+2]]= new Array();
			}
			vertNorm[polyArray[i][k+2]].push(c);
		}
		polyNorm[i] = c;
	}	
	
	// create coordinate and normal arrays for all vertices
	// averages all normals stored in each particular vertex
	// index
	var vnorm;
	var d, df;	
	for(var i = 0; i < polyArray.length; ++i) {		
		for(var j = 0; j < polyArray[i].length; ++j){
			coordArray.push(SHARK_COORD[polyArray[i][j]][0]);
			coordArray.push(SHARK_COORD[polyArray[i][j]][1]);
			coordArray.push(SHARK_COORD[polyArray[i][j]][2]);
			
			vnorm = vertNorm[polyArray[i][j]];
			d = [0,0,0];
			for(var ii = 0; ii < vnorm.length; ++ii){
				d = add(d,vnorm[ii]);
			}
			d[0] /= vnorm.length;
			d[1] /= vnorm.length;
			d[2] /= vnorm.length;
			d = normalize(d);
			smoothNormArray.push(d[0]);
			smoothNormArray.push(d[1]);
			smoothNormArray.push(d[2]);
			
			df = [0,0,0];
			df = add(df,polyNorm[i]);
			df = normalize(df);
			flatNormArray.push(df[0]);
			flatNormArray.push(df[1]);
			flatNormArray.push(df[2]);
		}		
	}
	
	// Build projection matrix
	var compM = new Array();
	var normM = new Array();
	var projM = new Array();
	var invProjM = new Array();
	var perspectiveProjection = perspectiveProj();
	var composition = compMatrix(perspectiveProjection,viewTransform(),worldTransform());
	for(var i = 0; i < 4; ++i) {
		for(var j = 0; j < 4; ++j) {
			compM.push(composition[j][i]);
		}
	}
	gl.uniformMatrix4fv(projectionMatrix, false, new Float32Array(compM));
	
	// Build transformation matrix for surface normals
	var normComposition = inverse(composition);
	normComposition = transpose(normComposition);
	for(var i = 0; i < 3; ++i) {
		for(var j = 0; j < 3; ++j) {
			normM.push(normComposition[j][i]);
		}
	}
	gl.uniformMatrix3fv(normalMatrix, false, new Float32Array(normM));
	
	for(var i = 0; i < 4; ++i) {
		for(var j = 0; j < 4; ++j) {
			projM.push(perspectiveProjection[j][i]);
		}
	}
	var invPerspectiveProjection = inverse(perspectiveProjection);
	for(var i = 0; i < 4; ++i) {
		for(var j = 0; j < 4; ++j) {
			invProjM.push(invPerspectiveProjection[j][i]);
		}
	}
	gl.uniformMatrix4fv(projection, false, new Float32Array(projM));
	gl.uniformMatrix4fv(invProjection, false, new Float32Array(invProjM));
	
	// Set depth handling instructions
	gl.depthFunc(gl.GREATER);
	gl.enable(gl.DEPTH_TEST);
	gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);
	
	// draw polygons
	drawTriangles(coordArray,smoothNormArray,flatNormArray);	
}

window.onload = initialize;