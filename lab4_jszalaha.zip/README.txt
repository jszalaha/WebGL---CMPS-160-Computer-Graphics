Lab 4 - Jordan Zalaha

I'd like to at least explain to you why my lab doesn't work and the steps that 
I took to try and make it work.

As you can see from my code I tried to implement the ray casting and unprojection 
method of picking without using three.js. The reason I didn't use three.js is 
because I spent most of my allotted time re-structuring my program 2 to use MV.js 
effectively for my transformations and projections and correctly implement a 
perspective view. By the time I had finished all of this (essentially re-doing 
program 2) it was too late for me to completely scrap all of that and re-write it 
using three.js instead, which honestly would have made picking a breeze, but I was 
unwilling since I had just put in all this effort. I had no trouble getting the 
unprojected rays from the mouse coordinates but what I found to be close to 
impossible was determining an intersection between this ray and my shark object. 
So there you have it, please look at my code so you can at least see I put in an 
effort.